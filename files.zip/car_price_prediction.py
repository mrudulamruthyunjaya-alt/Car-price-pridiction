"""Task 3: Car Price Prediction with scikit-learn.

Target: Selling_Price (in lakhs of rupees).
Approach: predict the *resale ratio* (selling price / showroom price), then
multiply back by the showroom price. This is stable and generalises to
expensive cars that trees / linear models would otherwise never extrapolate to.

Usage:  python car_price_prediction.py [path_to_csv]
"""
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.base import BaseEstimator, RegressorMixin, clone
from sklearn.model_selection import train_test_split, cross_val_score, KFold
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler, TargetEncoder
from sklearn.linear_model import Ridge
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.inspection import permutation_importance
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error

CSV = sys.argv[1] if len(sys.argv) > 1 else "/mnt/user-data/uploads/car_data_1_.csv"
OUT = "/mnt/user-data/outputs/"

# ------------------------------------------------------------ 1. Load & clean
df = pd.read_csv(CSV)
print("Raw shape:", df.shape)
df = df.drop_duplicates().reset_index(drop=True)
df["Car_Name"] = df["Car_Name"].str.strip().str.lower()
print("After dropping duplicates:", df.shape, "| missing values:", int(df.isna().sum().sum()))

# ------------------------------------------------------------ 2. Feature engineering
df["Car_Age"] = df["Year"].max() + 1 - df["Year"]      # age relative to newest listing
df["Log_Kms"] = np.log1p(df["Driven_kms"])             # tames the 500,000 km outlier
df["Log_Present"] = np.log(df["Present_Price"])        # price effects are multiplicative
df["Is_Diesel"] = (df["Fuel_Type"] == "Diesel").astype(int)

NUM = ["Log_Present", "Car_Age", "Log_Kms", "Owner", "Is_Diesel"]
CAT = ["Fuel_Type", "Selling_type", "Transmission"]
# "Brand goodwill": how well a car name holds its value. Car_Name is
# target-encoded; the encoder is fitted only on training folds inside the
# pipeline (with internal cross-fitting) so there is no target leakage.
GOODWILL = ["Car_Name"]

X = df[NUM + CAT + GOODWILL + ["Present_Price"]]
y = df["Selling_Price"]


class RatioRegressor(BaseEstimator, RegressorMixin):
    """Learn log(selling / showroom price); predict price = ratio * showroom."""
    def __init__(self, base=None):
        self.base = base

    def fit(self, X, y):
        self.model_ = clone(self.base).fit(X, np.log(y / X["Present_Price"]))
        return self

    def predict(self, X):
        return np.exp(self.model_.predict(X)) * X["Present_Price"].values


def build(model, scale=False):
    pre = ColumnTransformer([
        ("num", StandardScaler() if scale else "passthrough", NUM),
        ("cat", OneHotEncoder(handle_unknown="ignore"), CAT),
        ("goodwill", TargetEncoder(target_type="continuous", random_state=42), GOODWILL),
    ])
    return RatioRegressor(Pipeline([("pre", pre), ("model", model)]))


models = {
    "Ridge Regression": build(Ridge(alpha=1.0), scale=True),
    "Random Forest": build(RandomForestRegressor(n_estimators=300, random_state=42)),
    "Gradient Boosting": build(GradientBoostingRegressor(random_state=42)),
}

# ------------------------------------------------------------ 3. Split + cross-validate
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
cv = KFold(5, shuffle=True, random_state=42)

print("\n5-fold CV R^2 on training data:")
for name, m in models.items():
    s = cross_val_score(m, X_train, y_train, cv=cv, scoring="r2")
    print(f"  {name:20s} {s.mean():.3f} (+/- {s.std():.3f})")

# ------------------------------------------------------------ 4. Evaluate on test set
print("\nHeld-out test set results (price in lakhs):")
rows, preds = [], {}
for name, m in models.items():
    m.fit(X_train, y_train)
    p = m.predict(X_test)
    preds[name] = p
    rows.append({"Model": name, "R2": r2_score(y_test, p),
                 "MAE": mean_absolute_error(y_test, p),
                 "RMSE": np.sqrt(mean_squared_error(y_test, p))})
res = pd.DataFrame(rows).set_index("Model").round(3)
print(res)
res.to_csv(OUT + "car_model_results.csv")

best_name = res["R2"].idxmax()
best = models[best_name]
print("\nBest model on test set:", best_name)

# ------------------------------------------------------------ 5. Plots
fig, ax = plt.subplots(1, 3, figsize=(17, 5))
ax[0].hist(y, bins=30, color="#4C72B0", edgecolor="white")
ax[0].set(title="Selling price distribution", xlabel="Selling price (lakhs)", ylabel="Cars")

p = preds[best_name]
ax[1].scatter(y_test, p, alpha=0.7, color="#DD8452", edgecolor="k", linewidth=0.3)
lim = [0, max(y_test.max(), p.max()) * 1.05]
ax[1].plot(lim, lim, "k--", lw=1)
ax[1].set(title=f"Actual vs predicted ({best_name})",
          xlabel="Actual price (lakhs)", ylabel="Predicted price (lakhs)")

feat_cols = NUM + CAT + GOODWILL
imp = permutation_importance(best, X_test, y_test, n_repeats=20, random_state=42, scoring="r2")
imp_s = pd.Series(imp.importances_mean, index=X_test.columns)[feat_cols].sort_values()
imp_s.plot.barh(ax=ax[2], color="#55A868")
ax[2].set(title="Feature importance (permutation, drop in R2)", xlabel="Importance")
plt.tight_layout()
plt.savefig(OUT + "car_price_analysis.png", dpi=120)
print("\nTop features:\n", imp_s.sort_values(ascending=False).head(5).round(3))

# ------------------------------------------------------------ 6. Predict a new car
new = pd.DataFrame([{
    "Log_Present": np.log(9.5), "Car_Age": 5, "Log_Kms": np.log1p(40000),
    "Owner": 0, "Is_Diesel": 0, "Fuel_Type": "Petrol", "Selling_type": "Dealer",
    "Transmission": "Manual", "Car_Name": "city", "Present_Price": 9.5}])
print(f"\nExample: 5-year-old Honda City, 40,000 km, showroom price 9.5 lakh "
      f"-> predicted resale {best.predict(new)[0]:.2f} lakh")
